<?php
$golonganObj = new Golongan($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'tambah_golongan') {
            $kode_golongan = $_POST['kode_golongan'];
            $nama_golongan = $_POST['nama_golongan'];
            $golonganObj->tambahGolongan($kode_golongan, $nama_golongan);
        } elseif ($_POST['action'] == 'edit_golongan') {
            $id_golongan = $_POST['edit_id_golongan'];
            $kode_golongan = $_POST['edit_kode_golongan'];
            $nama_golongan = $_POST['edit_nama_golongan'];
            $golonganObj->editGolongan($id_golongan, $kode_golongan, $nama_golongan);
        }
    }
}

if (isset($_GET['hapus_golongan'])) {
    $id_golongan_hapus = $_GET['hapus_golongan'];
    $golonganObj->hapusGolongan($id_golongan_hapus);
    header("Location: golongan.php");
    exit();
}

$golongans = $golonganObj->bacaDataGolongan();
?>