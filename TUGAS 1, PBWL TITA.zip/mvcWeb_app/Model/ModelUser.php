<?php
$userModel = new User($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'tambah_user') {
            $userModel->tambahUser($_POST);
        } elseif ($_POST['action'] == 'edit_user') {
            $userModel->editUser($_POST);
        }
    }
}

if (isset($_GET['hapus_user'])) {
    $userModel->hapusUser($_GET['hapus_user']);
    header("Location: user.php");
    exit();
}

$users = $userModel->bacaDataUser();