<?php
class PelangganManager {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function tambahPelanggan($golongan, $nomorPelanggan, $namaPelanggan, $alamatPelanggan, $noHpPelanggan, $ktpPelanggan, $nomorSeri, $noMeteranPelanggan, $pelangganAktif) {
        $sql = "INSERT INTO pelanggan (golongan, nomor_pelanggan, nama_pelanggan, alamat_pelanggan, no_hp_pelanggan, ktp_pelanggan, nomor_seri, no_meteran_pelanggan, pelanggan_aktif, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssssssi", $golongan, $nomorPelanggan, $namaPelanggan, $alamatPelanggan, $noHpPelanggan, $ktpPelanggan, $nomorSeri, $noMeteranPelanggan, $pelangganAktif);
        $stmt->execute();

        if ($stmt->error) {
            die("Error: " . $stmt->error);
        }

        $stmt->close();
    }

    public function editPelanggan($idPelanggan, $golongan, $nomorPelanggan, $namaPelanggan, $alamatPelanggan, $noHpPelanggan, $ktpPelanggan, $nomorSeri, $noMeteranPelanggan, $pelangganAktif) {
        $sql = "UPDATE pelanggan SET golongan=?, nomor_pelanggan=?, nama_pelanggan=?, alamat_pelanggan=?, no_hp_pelanggan=?, ktp_pelanggan=?, nomor_seri=?, no_meteran_pelanggan=?, pelanggan_aktif=?, updated_at=NOW() WHERE id_pelanggan=?";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssssiiii", $golongan, $nomorPelanggan, $namaPelanggan, $alamatPelanggan, $noHpPelanggan, $ktpPelanggan, $nomorSeri, $noMeteranPelanggan, $pelangganAktif, $idPelanggan);
        $stmt->execute();

        if ($stmt->error) {
            die("Error: " . $stmt->error);
        }

        $stmt->close();
    }

    public function hapusPelanggan($idPelanggan) {
        $sql = "DELETE FROM pelanggan WHERE id_pelanggan=?";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $idPelanggan);
        $stmt->execute();

        if ($stmt->error) {
            die("Error: " . $stmt->error);
        }

        $stmt->close();
    }

    public function getDataPelanggan() {
        $result = $this->conn->query("SELECT * FROM pelanggan");
        $pelanggans = $result->fetch_all(MYSQLI_ASSOC);

        return $pelanggans;
    }
}
?>