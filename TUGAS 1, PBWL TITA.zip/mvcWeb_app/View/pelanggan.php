<?php
include('../App/Config/Config.php');
include('../App/controller/ControllerPelanggan.php');
include('../Model/ModelPelanggan.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>

    <div class="container mt-5">
        <a href="golongan" class="btn btn-warning">Data Golongan</a>
        <a href="user" class="btn btn-info">Data Pengguna</a>
        <a href="pelanggan" class="btn btn-success">Data Pelanggan</a>
        <a href="logout" class="btn btn-danger">Keluar</a>

        <h2>Data Pelanggan</h2>

        <!-- Tombol Tambah -->
        <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalPelanggan">Tambah
            Pelanggan</button>

        <!-- Tabel Data Pelanggan -->
        <div class="row">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID Pelanggan</th>
                            <th>Golongan</th>
                            <th>Nomor Pelanggan</th>
                            <th>Nama Pelanggan</th>
                            <th>Alamat Pelanggan</th>
                            <th>No. HP Pelanggan</th>
                            <th>KTP Pelanggan</th>
                            <th>Nomor Seri</th>
                            <th>No. Meteran</th>
                            <th>Pelanggan Aktif</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($pelanggans as $pelanggan) : ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $pelanggan['golongan']; ?></td>
                            <td><?= $pelanggan['nomor_pelanggan']; ?></td>
                            <td><?= $pelanggan['nama_pelanggan']; ?></td>
                            <td><?= $pelanggan['alamat_pelanggan']; ?></td>
                            <td><?= $pelanggan['no_hp_pelanggan']; ?></td>
                            <td><?= $pelanggan['ktp_pelanggan']; ?></td>
                            <td><?= $pelanggan['nomor_seri']; ?></td>
                            <td><?= $pelanggan['no_meteran_pelanggan']; ?></td>
                            <td><?= $pelanggan['pelanggan_aktif'] ? 'Aktif' : 'Non-Aktif'; ?></td>
                            <td><?= $pelanggan['created_at']; ?></td>
                            <td><?= $pelanggan['updated_at']; ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#modalEditPelanggan<?= $pelanggan['id_pelanggan']; ?>">Edit</button>
                                <a href="?hapus_pelanggan=<?= $pelanggan['id_pelanggan']; ?>"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Apakah Anda yakin ingin menghapus pelanggan ini?')">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- Modal Tambah Pelanggan -->
    <div class="modal fade" id="modalPelanggan" tabindex="-1" aria-labelledby="modalPelangganLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalPelangganLabel">Tambah Pelanggan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Form Tambah Pelanggan -->
                    <form action="" method="POST">
                        <input type="hidden" name="action" value="tambah_pelanggan">
                        <div class="mb-3">
                            <label for="golongan" class="form-label">Golongan</label>
                            <select class="form-control" id="golongan" name="golongan" required>
                                <?php foreach ($golongans as $golongan): ?>
                                <option value="<?= $golongan['nama_golongan'] ?>"><?= $golongan['nama_golongan'] ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="nomor_pelanggan" class="form-label">Nomor Pelanggan</label>
                            <input type="text" class="form-control" id="nomor_pelanggan" name="nomor_pelanggan"
                                required>
                        </div>
                        <div class="mb-3">
                            <label for="nama_pelanggan" class="form-label">Nama Pelanggan</label>
                            <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" required>
                        </div>
                        <div class="mb-3">
                            <label for="alamat_pelanggan" class="form-label">Alamat Pelanggan</label>
                            <textarea class="form-control" id="alamat_pelanggan" name="alamat_pelanggan"
                                required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="no_hp_pelanggan" class="form-label">No. HP Pelanggan</label>
                            <input type="text" class="form-control" id="no_hp_pelanggan" name="no_hp_pelanggan">
                        </div>
                        <div class="mb-3">
                            <label for="ktp_pelanggan" class="form-label">KTP Pelanggan</label>
                            <input type="text" class="form-control" id="ktp_pelanggan" name="ktp_pelanggan">
                        </div>
                        <div class="mb-3">
                            <label for="nomor_seri" class="form-label">Nomor Seri</label>
                            <input type="text" class="form-control" id="nomor_seri" name="nomor_seri">
                        </div>
                        <div class="mb-3">
                            <label for="no_meteran_pelanggan" class="form-label">No. Meteran</label>
                            <input type="text" class="form-control" id="no_meteran_pelanggan"
                                name="no_meteran_pelanggan">
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="pelanggan_aktif" name="pelanggan_aktif"
                                value="1" checked>
                            <label class="form-check-label" for="pelanggan_aktif">Aktif</label>
                        </div>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Edit Pelanggan -->
    <?php foreach ($pelanggans as $pelanggan) : ?>
    <div class="modal fade" id="modalEditPelanggan<?= $pelanggan['id_pelanggan']; ?>" tabindex="-1"
        aria-labelledby="modalEditPelangganLabel<?= $pelanggan['id_pelanggan']; ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditPelangganLabel<?= $pelanggan['id_pelanggan']; ?>">Edit
                        Pelanggan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Form Edit Pelanggan -->
                    <form action="" method="POST">
                        <input type="hidden" name="action" value="edit_pelanggan">
                        <input type="hidden" name="edit_id_pelanggan" value="<?= $pelanggan['id_pelanggan']; ?>">
                        <div class="mb-3">
                            <label for="edit_golongan" class="form-label">Golongan</label>
                            <select class="form-control" id="edit_golongan" name="golongan" required>
                                <?php foreach ($golongans as $golongan): ?>
                                <option value="<?= $golongan['nama_golongan'] ?>"
                                    <?= $pelanggan['golongan'] === $golongan['nama_golongan'] ? 'selected' : ''; ?>>
                                    <?= $golongan['nama_golongan'] ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_nomor_pelanggan" class="form-label">Nomor Pelanggan</label>
                            <input type="text" class="form-control" id="edit_nomor_pelanggan" name="nomor_pelanggan"
                                value="<?= $pelanggan['nomor_pelanggan']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_nama_pelanggan" class="form-label">Nama Pelanggan</label>
                            <input type="text" class="form-control" id="edit_nama_pelanggan" name="nama_pelanggan"
                                value="<?= $pelanggan['nama_pelanggan']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_alamat_pelanggan" class="form-label">Alamat Pelanggan</label>
                            <textarea class="form-control" id="edit_alamat_pelanggan" name="alamat_pelanggan"
                                required><?= $pelanggan['alamat_pelanggan']; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit_no_hp_pelanggan" class="form-label">No. HP Pelanggan</label>
                            <input type="text" class="form-control" id="edit_no_hp_pelanggan" name="no_hp_pelanggan"
                                value="<?= $pelanggan['no_hp_pelanggan']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="edit_ktp_pelanggan" class="form-label">KTP Pelanggan</label>
                            <input type="text" class="form-control" id="edit_ktp_pelanggan" name="ktp_pelanggan"
                                value="<?= $pelanggan['ktp_pelanggan']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="edit_nomor_seri" class="form-label">Nomor Seri</label>
                            <input type="text" class="form-control" id="edit_nomor_seri" name="nomor_seri"
                                value="<?= $pelanggan['nomor_seri']; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="edit_no_meteran_pelanggan" class="form-label">No. Meteran</label>
                            <input type="text" class="form-control" id="edit_no_meteran_pelanggan"
                                name="no_meteran_pelanggan" value="<?= $pelanggan['no_meteran_pelanggan']; ?>">
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="edit_pelanggan_aktif"
                                name="pelanggan_aktif" value="1" <?= $pelanggan['pelanggan_aktif'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="edit_pelanggan_aktif">Aktif</label>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>

</html>